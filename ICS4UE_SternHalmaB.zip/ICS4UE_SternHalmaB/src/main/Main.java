package main;

import gui_client.CCPanelClient;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;

public class Main
{
	static CCPanelClient panel;
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Chinese Checkers AI");
		// Initiate panel here:
		panel = new CCPanelClient();
		frame.add(panel);
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame.addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(WindowEvent e)
			{
				panel.stop();
				frame.dispose();
				
			}
		});
		
		frame.setVisible(true);
		panel.go();
	}
}
