# ChineseCheckersClient
An Chinese checkers client for the summative project 

Google doc @ tinyurl.com/chinesecheckersprotocol
or https://docs.google.com/document/d/165w04v6uA0_nnYBve51SSioRK0UV3YsJkCdvD9LzKsY/edit?pref=2&pli=1
